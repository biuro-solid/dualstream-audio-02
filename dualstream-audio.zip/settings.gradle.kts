rootProject.name = "dualstream-audio"
include(":app")